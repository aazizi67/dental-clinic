<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <title>@yield('title', 'سیستم مطب دندانپزشکی دکتر علی عزیزی')</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        * {
            font-family: 'Vazir', sans-serif;
        }
        
        body {
            background-color: #F8FAFC;
            color: #1E293B;
        }
        
        .navbar {
            background: white !important;
            box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
            border-bottom: 1px solid #E2E8F0;
        }
        
        .navbar-brand {
            color: #3B82F6 !important;
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .sidebar {
            background: white;
            box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
            min-height: calc(100vh - 76px);
            border-left: 1px solid #E2E8F0;
        }
        
        .nav-pills .nav-link {
            color: #64748B;
            border-radius: 8px;
            margin-bottom: 4px;
            padding: 12px 16px;
            transition: all 0.2s;
        }
        
        .nav-pills .nav-link:hover {
            background-color: #EFF6FF;
            color: #3B82F6;
        }
        
        .nav-pills .nav-link.active {
            background-color: #3B82F6;
            color: white;
        }
        
        .card {
            border: 1px solid #E2E8F0;
            box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
            border-radius: 12px;
        }
        
        .btn-primary {
            background-color: #3B82F6;
            border-color: #3B82F6;
        }
        
        .main-content {
            padding: 24px;
        }
    </style>
    
    @stack('styles')
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{ route('dashboard') }}">
                <i class="bi bi-heart-pulse-fill me-2"></i>
                مطب دندانپزشکی دکتر علی عزیزی
            </a>
            
            <div class="d-flex">
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i>
                        {{ auth()->user()->name }}
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <form method="POST" action="{{ route('logout') }}" class="d-inline">
                                @csrf
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-2"></i>خروج
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column nav-pills">
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" 
                               href="{{ route('dashboard') }}">
                                <i class="bi bi-speedometer2 me-2"></i>
                                داشبورد
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('patients.*') ? 'active' : '' }}" 
                               href="{{ route('patients.index') }}">
                                <i class="bi bi-people me-2"></i>
                                بیماران
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('appointments.*') ? 'active' : '' }}" 
                               href="{{ route('appointments.index') }}">
                                <i class="bi bi-calendar-check me-2"></i>
                                نوبت‌ها
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('treatments.*') ? 'active' : '' }}" 
                               href="{{ route('treatments.index') }}">
                                <i class="bi bi-heart-pulse me-2"></i>
                                طرح درمان
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('treatments.chart') ? 'active' : '' }}" 
                               href="{{ route('treatments.chart') }}">
                                <i class="bi bi-diagram-3 me-2"></i>
                                چارت دندانی
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('payments.*') ? 'active' : '' }}" 
                               href="{{ route('payments.index') }}">
                                <i class="bi bi-cash-coin me-2"></i>
                                پرداخت‌ها
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle me-2"></i>
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
                
                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-circle me-2"></i>
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @yield('content')
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    
    @stack('scripts')
</body>
</html>