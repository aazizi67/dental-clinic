<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Appointment;
use App\Models\Patient;
use App\Models\User;

class AppointmentController extends Controller
{
    public function index(Request $request)
    {
        $query = Appointment::with(['patient', 'doctor']);
        
        if ($request->has('date') && $request->date) {
            $query->whereDate('appointment_date', $request->date);
        }
        
        if ($request->has('status') && $request->status) {
            $query->where('status', $request->status);
        }
        
        $appointments = $query->orderBy('appointment_date')
                             ->orderBy('appointment_time')
                             ->paginate(20);
        
        return view('appointments.index', compact('appointments'));
    }
    
    public function create()
    {
        $patients = Patient::orderBy('first_name')->get();
        $doctors = User::where('role', 'doctor')->where('is_active', true)->get();
        
        return view('appointments.create', compact('patients', 'doctors'));
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'doctor_id' => 'required|exists:users,id',
            'appointment_date' => 'required|date|after_or_equal:today',
            'appointment_time' => 'required',
            'duration' => 'required|integer|min:15|max:180',
            'type' => 'required|in:consultation,treatment,follow_up,emergency',
            'chief_complaint' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);
        
        $appointment = Appointment::create([
            'patient_id' => $request->patient_id,
            'doctor_id' => $request->doctor_id,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'duration' => $request->duration,
            'type' => $request->type,
            'status' => 'scheduled',
            'chief_complaint' => $request->chief_complaint,
            'notes' => $request->notes,
            'created_by' => auth()->id(),
        ]);
        
        return redirect()->route('appointments.show', $appointment)
            ->with('success', 'نوبت با موفقیت ثبت شد.');
    }
    
    public function show(Appointment $appointment)
    {
        $appointment->load(['patient', 'doctor', 'createdBy']);
        
        return view('appointments.show', compact('appointment'));
    }
}