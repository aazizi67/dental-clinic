<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\Payment;
use App\Models\TreatmentPlan;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_patients' => Patient::count(),
            'today_appointments' => Appointment::whereDate('appointment_date', today())->count(),
            'pending_appointments' => Appointment::where('status', 'scheduled')->count(),
            'monthly_income' => Payment::whereMonth('created_at', now()->month)->sum('amount'),
            'active_treatments' => TreatmentPlan::where('status', 'active')->count(),
        ];
        
        $todayAppointments = Appointment::with(['patient', 'doctor'])
            ->whereDate('appointment_date', today())
            ->orderBy('appointment_time')
            ->get();
        
        $recentPayments = Payment::with('patient')
            ->latest()
            ->take(5)
            ->get();
        
        $newPatients = Patient::latest()
            ->take(5)
            ->get();
        
        $monthlyIncome = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = now()->subMonths($i);
            $monthlyIncome[] = [
                'month' => $month->format('M Y'),
                'income' => Payment::whereMonth('created_at', $month->month)
                    ->whereYear('created_at', $month->year)
                    ->sum('amount')
            ];
        }
        
        return view('dashboard', compact(
            'stats', 
            'todayAppointments', 
            'recentPayments', 
            'newPatients',
            'monthlyIncome'
        ));
    }
}