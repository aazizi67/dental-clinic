<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\TreatmentPlan;
use App\Models\TreatmentItem;
use App\Models\TreatmentType;
use App\Models\Price;

class TreatmentController extends Controller
{
    public function index(Request $request)
    {
        $query = TreatmentPlan::with(['patient', 'doctor']);
        
        if ($request->has('patient_search') && $request->patient_search) {
            $search = $request->patient_search;
            $query->whereHas('patient', function($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }
        
        $treatmentPlans = $query->latest()->paginate(15);
        
        return view('treatments.index', compact('treatmentPlans'));
    }
    
    public function create()
    {
        $treatmentTypes = TreatmentType::active()->get();
        return view('treatments.create', compact('treatmentTypes'));
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'patient_phone' => 'required|string|exists:patients,phone',
            'treatment_items' => 'required|array|min:1',
            'treatment_items.*.tooth_number' => 'required|integer|between:1,48',
            'treatment_items.*.treatment_type_id' => 'required|exists:treatment_types,id',
        ]);
        
        $patient = Patient::where('phone', $request->patient_phone)->first();
        
        $treatmentPlan = TreatmentPlan::create([
            'patient_id' => $patient->id,
            'doctor_id' => auth()->id(),
            'title' => 'طرح درمان ' . $patient->full_name,
            'status' => 'active'
        ]);
        
        $totalCost = 0;
        
        foreach ($request->treatment_items as $item) {
            $treatmentType = TreatmentType::find($item['treatment_type_id']);
            
            $price = Price::where('tooth_number', $item['tooth_number'])
                         ->where('treatment_type_id', $treatmentType->id)
                         ->first();
            
            $cost = $price ? $price->price : $treatmentType->default_price;
            $totalCost += $cost;
            
            TreatmentItem::create([
                'treatment_plan_id' => $treatmentPlan->id,
                'tooth_number' => $item['tooth_number'],
                'treatment_type_id' => $treatmentType->id,
                'treatment_type' => $treatmentType->name,
                'cost' => $cost,
                'status' => 'pending'
            ]);
        }
        
        $treatmentPlan->update(['total_cost' => $totalCost]);
        
        return redirect()->route('treatments.show', $treatmentPlan)
            ->with('success', 'طرح درمان با موفقیت ایجاد شد.');
    }

    public function show(TreatmentPlan $treatment)
    {
        $treatment->load(['patient', 'doctor', 'treatmentItems.treatmentType', 'payments']);
        
        return view('treatments.show', compact('treatment'));
    }
}