<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\User;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        $query = Patient::query();
        
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('national_code', 'like', "%{$search}%");
            });
        }
        
        $patients = $query->latest()->paginate(20);
        
        return view('patients.index', compact('patients'));
    }
    
    public function create()
    {
        return view('patients.create');
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'phone' => 'required|string|unique:patients,phone',
            'national_code' => 'nullable|string|size:10|unique:patients,national_code',
            'birth_date' => 'nullable|date',
            'gender' => 'nullable|in:male,female',
            'address' => 'nullable|string',
            'emergency_contact' => 'nullable|string',
            'medical_history' => 'nullable|string',
            'allergies' => 'nullable|string',
            'insurance_type' => 'nullable|in:none,social,health,supplementary',
            'insurance_number' => 'nullable|string',
        ]);
        
        $patient = Patient::create($request->all());
        
        return redirect()->route('patients.show', $patient)
            ->with('success', 'بیمار با موفقیت ثبت شد.');
    }
    
    public function show(Patient $patient)
    {
        $patient->load(['treatmentPlans', 'appointments' => function($q) {
            $q->latest();
        }]);
        
        return view('patients.show', compact('patient'));
    }
}