<?php $__env->startSection('title', 'داشبورد'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">داشبورد</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-download me-1"></i>
                گزارش
            </button>
        </div>
    </div>
</div>

<!-- آمار کلی -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card text-white" style="background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="fs-2 fw-bold"><?php echo e(number_format($stats['total_patients'])); ?></div>
                        <div class="fw-bold">کل بیماران</div>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-people" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card text-white" style="background: linear-gradient(135deg, #10B981 0%, #059669 100%);">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="fs-2 fw-bold"><?php echo e(number_format($stats['today_appointments'])); ?></div>
                        <div class="fw-bold">نوبت‌های امروز</div>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-calendar-check" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card text-white" style="background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="fs-2 fw-bold"><?php echo e(number_format($stats['pending_appointments'])); ?></div>
                        <div class="fw-bold">نوبت‌های در انتظار</div>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-clock" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card text-white" style="background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="fs-2 fw-bold"><?php echo e(number_format($stats['monthly_income'])); ?></div>
                        <div class="fw-bold">درآمد ماهانه (تومان)</div>
                    </div>
                    <div class="align-self-center">
                        <i class="bi bi-cash-coin" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- نوبت‌های امروز -->
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">نوبت‌های امروز</h5>
                <a href="<?php echo e(route('appointments.index')); ?>" class="btn btn-sm btn-outline-primary">مشاهده همه</a>
            </div>
            <div class="card-body">
                <?php if($todayAppointments->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>زمان</th>
                                    <th>بیمار</th>
                                    <th>نوع</th>
                                    <th>وضعیت</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $todayAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold"><?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('H:i')); ?></td>
                                    <td><?php echo e($appointment->patient->name ?? 'نامشخص'); ?></td>
                                    <td>معاینه</td>
                                    <td>
                                        <?php if($appointment->status == 'scheduled'): ?>
                                            <span class="badge bg-primary">زمان‌بندی شده</span>
                                        <?php elseif($appointment->status == 'completed'): ?>
                                            <span class="badge bg-success">تکمیل شده</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">لغو شده</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="bi bi-calendar-x" style="font-size: 3rem; color: #6c757d;"></i>
                        <p class="mt-2 text-muted">امروز نوبتی ثبت نشده است</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- آخرین پرداخت‌ها -->
    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">آخرین پرداخت‌ها</h5>
                <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-sm btn-outline-primary">مشاهده همه</a>
            </div>
            <div class="card-body">
                <?php if($recentPayments->count() > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item px-0">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h6 class="mb-1"><?php echo e($payment->patient->name ?? 'نامشخص'); ?></h6>
                                    <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($payment->created_at)->diffForHumans()); ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-success"><?php echo e(number_format($payment->amount)); ?> تومان</span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="bi bi-credit-card" style="font-size: 3rem; color: #6c757d;"></i>
                        <p class="mt-2 text-muted">پرداختی ثبت نشده است</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- نمودار درآمد -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">نمودار درآمد 6 ماه اخیر</h5>
            </div>
            <div class="card-body">
                <canvas id="incomeChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // نمودار درآمد
    const ctx = document.getElementById('incomeChart').getContext('2d');
    const incomeChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chartLabels ?? ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور']); ?>,
            datasets: [{
                label: 'درآمد (تومان)',
                data: <?php echo json_encode($chartData ?? [0, 0, 0, 0, 0, 0]); ?>,
                backgroundColor: 'rgba(37, 99, 235, 0.8)',
                borderColor: 'rgba(37, 99, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString('fa-IR');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y.toLocaleString('fa-IR') + ' تومان';
                        }
                    }
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u619197738/domains/draliazizi.net/public_html/clinic/resources/views/dashboard.blade.php ENDPATH**/ ?>