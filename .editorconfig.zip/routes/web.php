<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\TreatmentController;
use App\Http\Controllers\PaymentController;

// صفحه اصلی - ریدایرکت به پنل
Route::get('/', function () {
    return redirect()->route('login');
});

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.submit');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Protected Routes (نیاز به ورود)
Route::middleware('auth')->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Patient Management
    Route::resource('patients', PatientController::class);
    Route::post('/patients/search', [PatientController::class, 'search'])->name('patients.search');
    
    // Appointments
    Route::resource('appointments', AppointmentController::class);
    Route::get('/calendar', [AppointmentController::class, 'calendar'])->name('calendar');
    
    // Treatment Plans
    Route::resource('treatments', TreatmentController::class);
    Route::get('/chart', [TreatmentController::class, 'chart'])->name('treatments.chart');
    
    // Payments
    Route::resource('payments', PaymentController::class);
    Route::get('/reports', [PaymentController::class, 'reports'])->name('reports');
    
    // Management Pages (فقط دکتر)
    Route::middleware('can:manage-system')->group(function () {
        Route::get('/treatment-types', [TreatmentController::class, 'types'])->name('treatment-types.index');
        Route::post('/treatment-types', [TreatmentController::class, 'storeType'])->name('treatment-types.store');
        Route::get('/prices', [TreatmentController::class, 'prices'])->name('prices.index');
        Route::post('/prices', [TreatmentController::class, 'updatePrices'])->name('prices.update');
    });
});

// API Routes for AJAX
Route::prefix('api')->middleware('auth')->group(function () {
    Route::post('/get-patient', [PatientController::class, 'getPatient']);
    Route::post('/get-prices', [TreatmentController::class, 'getPrices']);
});