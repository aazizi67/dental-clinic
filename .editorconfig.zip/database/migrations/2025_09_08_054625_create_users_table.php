Schema::create('users', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('phone')->unique();  // این خط مهمه!
    $table->string('email')->nullable();
    $table->string('password');
    $table->enum('role', ['admin', 'doctor', 'secretary', 'assistant', 'patient']);
    $table->boolean('is_active')->default(true);
    $table->rememberToken();
    $table->timestamps();
});